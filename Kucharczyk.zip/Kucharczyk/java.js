<script LANGUAGE="JavaScript">

function f()
{
document.bgColor="black";
}

</script>